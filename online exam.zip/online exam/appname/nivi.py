from flask import *
app = Flask(__name__)

@app.route('/loginpage')
def loginpage():
   return render_template("loginpage.html")
@app.route('/cppques')
def cppques():
   return render_template("cppques.html")
@app.route('/cques')
def cques():
   return render_template("cques.html")
@app.route('/javaques')
def javaques():
   return render_template("javaques.html")
   
@app.route('/register')
def register():
   return render_template("register.html")

if __name__ == '__main__':
   app.run(debug=True)
